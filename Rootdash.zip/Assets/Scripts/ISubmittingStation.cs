using System.Collections;
namespace StinkySteak.Rootdash.Station
{
    public interface ISubmittingStation
    {
        
    }
}