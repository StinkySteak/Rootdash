namespace StinkySteak.Rootdash.Launcher
{
    public class MenuLauncher : GameLauncher
    {
        private void Awake()
        {
            SpawnDependencyManager();
        }
    }
}