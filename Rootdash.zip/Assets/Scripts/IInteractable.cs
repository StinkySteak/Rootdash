namespace StinkySteak.Rootdash.Interactable
{
    public interface IInteractable
    {
        string Name { get; }

        void Interact();
    }
}